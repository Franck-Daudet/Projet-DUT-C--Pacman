/**
 * \file main.cpp
 * \author Franck Daudet
 * \author Nicolas Jaubert
 * \author Enzo Vargas
 * \author Justin De Sio
 * \author Valere Coroller
 */

#include "Nos_fichiers/game.h"

using namespace std;

// Start game
/**
 * @brief main
 * @return
 */
int main()
{
    PacMan();
}
