var searchData=
[
  ['settings_2eh_66',['settings.h',['../settings_8h.html',1,'']]],
  ['start_2dend_5fscreen_2eh_67',['Start-End_Screen.h',['../_start-_end___screen_8h.html',1,'']]]
];
