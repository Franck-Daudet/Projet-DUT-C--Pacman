var searchData=
[
  ['stringmatrix_118',['StringMatrix',['../alias_8h.html#a67ed48c2ad0b7cfae9844004cd165700',1,'alias.h']]],
  ['stringvector_119',['StringVector',['../alias_8h.html#ab8e1ede88e2ff1c3b448334e6cbd3533',1,'alias.h']]]
];
