var searchData=
[
  ['intmatrix_116',['IntMatrix',['../alias_8h.html#ac79748a7ccb1288c54555f054740933a',1,'alias.h']]],
  ['intvector_117',['IntVector',['../alias_8h.html#a9b8f2f96749808efd0d975e75d96a71c',1,'alias.h']]]
];
